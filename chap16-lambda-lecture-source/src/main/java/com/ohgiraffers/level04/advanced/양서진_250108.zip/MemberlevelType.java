package com.ohgiraffers.level04.advanced;

public class MemberlevelType {

    private String basic;
    private String normal;
    private String pro;

    public MemberlevelType() {
    }

    public MemberlevelType(String basic, String normal, String pro) {
        this.basic = basic;
        this.normal = normal;
        this.pro = pro;
    }

}
